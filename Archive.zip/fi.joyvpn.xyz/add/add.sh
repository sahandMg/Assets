sudo docker container exec -it 2ffdf07617e4  ocpasswd -c /etc/ocserv/ocpasswd -g $2  $1

set username [lindex $argv 0];
set password [lindex $argv 1];
spawn bash ./add.sh $username $password
#expect "password for www-data\r"
#send -- "9218243ss\r"
expect  "Enter password:\r"
send -- "$password\r"
expect  "Re-enter password:\r"
send -- "$password\r"
expect eof

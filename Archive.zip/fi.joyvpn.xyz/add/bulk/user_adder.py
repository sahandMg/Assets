import os
import numpy
import pandas as pd
dataset = pd.read_csv('./linux_accounts.csv')
users = dataset.values[:,0]
passwords = dataset.values[:,1]
for (i,user) in enumerate(users):
    addUser = "expect add_exp.sh " + user + " " + str(passwords[i])
    os.system(addUser)

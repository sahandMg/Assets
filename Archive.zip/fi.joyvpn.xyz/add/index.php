<?php
if($_GET['adpassword']!= '9218243ss'){

        echo "<h1> Nothing TO DO Admin! </h1>";
        echo "<a href='http://fi.joyvpn.xyz:9095/index.html'>Client Register Page</a><hr>";
}else{
if(isset($_GET['username']) && !is_null($_GET['username'])){

shell_exec("expect ./add_exp.sh ".$_GET['username'].' '.$_GET['password'].' '.$_GET['group']);

$username = $_GET['username'];
$password = $_GET['password'];
echo "<h1> User $username with Password $password added successfully </h1>";
echo "<a href='http://fi.joyvpn.xyz:9095/index.html'>Client Register Page</a><hr>";
echo shell_exec("sudo cat /root/ocserv-docker/ocserv/ocpasswd | tail");
}else{

echo "<h1> Nothing TO DO ! </h1>" ;
}

}


<?php
if(isset($_GET['id']) && !is_null($_GET['id'])){
shell_exec("bash ./rem.sh ".$_GET['id']);
echo $_GET['id'];
}
elseif(isset($_GET['type']) && $_GET['type'] == 'add'){

}


sudo docker container exec  2ffdf07617e4  ocpasswd -d $1

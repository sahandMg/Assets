<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <title>Users List</title>
</head>
<body>

<?php
$string = shell_exec("bash ./status.sh");
$tableCells = explode(" ",$string);
$tableCells = array_slice(array_filter($tableCells),9);
//var_dump(array_filter($tableCells));
// var_dump($tableCells);
// var_dump(array_splice($tableCells,18,9));

?>
<table class="table table-striped">
  <thead>
    <tr>
      <th>id</th>
      <th>user</th>
      <th>group</th>
      <th>ip</th>
      <th>vpn-ip</th>
      <th>device</th>
      <th>since</th>
      <th>dtls-cipher</th>
      <th>status</th>
    </tr>
  </thead>
  <tbody>
    <?php
       for($i = 0 ; $i < count($tableCells) ; $i += 9){
         echo "<br>";
        echo "<tr>";
        for($t=0;$t<9;$t++){
          echo "<td>".array_slice($tableCells,$i)[$t]."</td>";
        }
        echo "</tr";
      }
    ?>
  </tbody>
</table>
</body>
</html>



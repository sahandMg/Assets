sudo docker exec 2ffdf07617e4 occtl "show users"
